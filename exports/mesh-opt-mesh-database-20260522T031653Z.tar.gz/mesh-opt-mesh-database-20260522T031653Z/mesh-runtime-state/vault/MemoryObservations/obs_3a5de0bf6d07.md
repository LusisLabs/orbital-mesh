# Observation obs_3a5de0bf6d07

- Kind: `integration_artifact_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:09.736645+00:00`

## Content

integration_artifact_recorded: planner=harness, probe_count=0

## Source Refs

```json
[
  {
    "artifact_key": "investigation_plan",
    "event_id": "evt_0007_c6289037",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
