# Observation obs_80aa7fe983c4

- Kind: `integration_readiness_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:09.353542+00:00`

## Content

integration_readiness_recorded: evo_ready=False, goose_ready=False, promptfoo_ready=False

## Source Refs

```json
[
  {
    "artifact_key": "integration_readiness",
    "event_id": "evt_0002_5dd7098e",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
