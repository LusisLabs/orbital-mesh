# Observation obs_19df3ebbe9cb

- Kind: `investigation_report`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `scenario_analysis`
- Author: `analyzer:investigation`
- Created: `2026-05-16T16:48:10.219185+00:00`

## Content

Investigation produced 4 finding(s), 2 RCA candidate(s), and uncertainty 0.19.

## Source Refs

```json
[
  {
    "event_id": "evt_0005_656fa9f5",
    "run_id": "run_20260516T164809_e4a71e58"
  },
  {
    "event_id": "evt_0006_2f6dcd49",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
