# Observation obs_247c1d8c9ab7

- Kind: `evidence_node_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.284794+00:00`

## Content

evidence_node_recorded: analyzer=kubernetes, kind=kubernetes_rollout

## Source Refs

```json
[
  {
    "artifact_key": "scenario_analysis",
    "event_id": "evt_0013_20ee8a5c",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
