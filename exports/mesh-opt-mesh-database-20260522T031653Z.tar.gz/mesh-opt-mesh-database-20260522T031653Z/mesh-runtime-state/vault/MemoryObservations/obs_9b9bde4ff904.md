# Observation obs_9b9bde4ff904

- Kind: `integration_artifact_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.487292+00:00`

## Content

integration_artifact_recorded: matched=False, service=default

## Source Refs

```json
[
  {
    "artifact_key": "service_agent",
    "event_id": "evt_0030_4286dfcf",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
