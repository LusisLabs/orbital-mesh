# Observation obs_bd6ef86c0abf

- Kind: `trigger_ready`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:09.706300+00:00`

## Content

trigger_ready: trigger_type=kubernetes_deployment_unhealthy

## Source Refs

```json
[
  {
    "artifact_key": "trigger",
    "event_id": "evt_0006_2f6dcd49",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
