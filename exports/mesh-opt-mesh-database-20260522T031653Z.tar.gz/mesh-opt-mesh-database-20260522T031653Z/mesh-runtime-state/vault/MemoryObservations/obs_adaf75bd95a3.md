# Observation obs_adaf75bd95a3

- Kind: `run_queued`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:09.349876+00:00`

## Content

run_queued: status=queued

## Source Refs

```json
[
  {
    "artifact_key": null,
    "event_id": "evt_0001_e8baea83",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
