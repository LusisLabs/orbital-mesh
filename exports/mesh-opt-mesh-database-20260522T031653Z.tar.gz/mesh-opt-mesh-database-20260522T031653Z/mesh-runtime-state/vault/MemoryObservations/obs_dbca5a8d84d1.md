# Observation obs_dbca5a8d84d1

- Kind: `risk_scope`
- Service: `frontend`
- Run: `run_20260516T170154_15cfa48b`
- Source Type: `scenario_analysis`
- Author: `analyzer:risk_scope`
- Created: `2026-05-16T17:01:57.525479+00:00`

## Content

recent rollback cooldown is active

## Source Refs

```json
[
  {
    "event_id": "evt_0005_e877b6b5",
    "run_id": "run_20260516T170154_15cfa48b"
  },
  {
    "event_id": "evt_0006_e4f53330",
    "run_id": "run_20260516T170154_15cfa48b"
  }
]
```
