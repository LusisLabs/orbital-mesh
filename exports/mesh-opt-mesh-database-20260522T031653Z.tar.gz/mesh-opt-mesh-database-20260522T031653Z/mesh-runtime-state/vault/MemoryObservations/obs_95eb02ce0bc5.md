# Observation obs_95eb02ce0bc5

- Kind: `evidence_node_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.331302+00:00`

## Content

evidence_node_recorded: analyzer=risk_scope, kind=risk_scope

## Source Refs

```json
[
  {
    "artifact_key": "scenario_analysis",
    "event_id": "evt_0017_89f54272",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
