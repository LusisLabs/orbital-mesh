# Observation obs_47ae1bff2426

- Kind: `kubernetes_rollout`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `scenario_analysis`
- Author: `analyzer:kubernetes`
- Created: `2026-05-16T16:48:10.210331+00:00`

## Content

Rollout status healthy; signatures: image_pull_failure.

## Source Refs

```json
[
  {
    "event_id": "evt_0005_656fa9f5",
    "run_id": "run_20260516T164809_e4a71e58"
  },
  {
    "event_id": "evt_0006_2f6dcd49",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
