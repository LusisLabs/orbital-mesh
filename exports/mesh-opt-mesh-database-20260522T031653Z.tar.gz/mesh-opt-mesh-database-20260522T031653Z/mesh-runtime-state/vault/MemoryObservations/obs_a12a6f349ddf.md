# Observation obs_a12a6f349ddf

- Kind: `integration_artifact_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.667633+00:00`

## Content

integration_artifact_recorded: trace_version=mesh_task_trace_v1, trigger_type=kubernetes_deployment_unhealthy

## Source Refs

```json
[
  {
    "artifact_key": "task_trace",
    "event_id": "evt_0035_2545eee9",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
