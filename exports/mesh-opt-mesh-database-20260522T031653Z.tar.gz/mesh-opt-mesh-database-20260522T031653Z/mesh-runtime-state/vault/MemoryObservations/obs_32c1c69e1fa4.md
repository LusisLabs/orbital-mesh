# Observation obs_32c1c69e1fa4

- Kind: `investigation_ready`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.182754+00:00`

## Content

investigation_ready: finding_count=4, probe_count=2, stop_reason=harness_llm_planner_error:ObserverClientError, uncertainty=0.191

## Source Refs

```json
[
  {
    "artifact_key": "investigation_report",
    "event_id": "evt_0011_ce00f4c7",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
