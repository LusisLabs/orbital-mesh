# Observation obs_e17c1cf4f6ad

- Kind: `hypothesis_ranked`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.534618+00:00`

## Content

hypothesis_ranked: recommended_action=rollback_deployment, top_hypothesis=h_rca_incorrect_image_reference

## Source Refs

```json
[
  {
    "artifact_key": "ranked_hypotheses",
    "event_id": "evt_0032_3ef29446",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
