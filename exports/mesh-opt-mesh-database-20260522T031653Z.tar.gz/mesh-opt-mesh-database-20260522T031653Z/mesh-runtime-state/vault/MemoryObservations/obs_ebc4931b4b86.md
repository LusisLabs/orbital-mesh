# Observation obs_ebc4931b4b86

- Kind: `integration_artifact_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.748482+00:00`

## Content

integration_artifact_recorded: passed=True, score=0.875

## Source Refs

```json
[
  {
    "artifact_key": "trajectory_score",
    "event_id": "evt_0036_481d8d16",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
