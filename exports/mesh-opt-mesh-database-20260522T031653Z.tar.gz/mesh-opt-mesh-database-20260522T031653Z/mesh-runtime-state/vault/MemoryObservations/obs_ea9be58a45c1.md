# Observation obs_ea9be58a45c1

- Kind: `risk_scope`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `scenario_analysis`
- Author: `analyzer:risk_scope`
- Created: `2026-05-16T16:48:10.228265+00:00`

## Content

No elevated risk scope detected.

## Source Refs

```json
[
  {
    "event_id": "evt_0005_656fa9f5",
    "run_id": "run_20260516T164809_e4a71e58"
  },
  {
    "event_id": "evt_0006_2f6dcd49",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
