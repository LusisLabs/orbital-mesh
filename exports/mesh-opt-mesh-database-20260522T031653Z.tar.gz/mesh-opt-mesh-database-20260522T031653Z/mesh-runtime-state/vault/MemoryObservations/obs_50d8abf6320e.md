# Observation obs_50d8abf6320e

- Kind: `evidence_node_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.340218+00:00`

## Content

evidence_node_recorded: analyzer=memory_relevance, kind=active_memory

## Source Refs

```json
[
  {
    "artifact_key": "scenario_analysis",
    "event_id": "evt_0018_ae9e8a8e",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
