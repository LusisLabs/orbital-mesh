# Observation obs_0b36f4e0dd59

- Kind: `subdecision_recorded`
- Service: `frontend`
- Run: `run_20260516T164809_e4a71e58`
- Source Type: `run_event`
- Author: `mesh_control_plane`
- Created: `2026-05-16T16:48:10.357390+00:00`

## Content

subdecision_recorded: analyzer=regression, recommendation=no_action, requires_review=False

## Source Refs

```json
[
  {
    "artifact_key": "scenario_analysis",
    "event_id": "evt_0020_bea5f81f",
    "run_id": "run_20260516T164809_e4a71e58"
  }
]
```
