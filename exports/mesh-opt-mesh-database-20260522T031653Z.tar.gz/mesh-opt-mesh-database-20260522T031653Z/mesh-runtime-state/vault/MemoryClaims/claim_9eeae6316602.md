# Claim claim_9eeae6316602

- Tier: `semantic`
- State: `active`
- Confidence: `0.697`
- Freshness: `0.9999999999959888`
- Superseded By: `none`
- Updated: `2026-05-16T17:01:57.501864+00:00`

## Statement

Investigation produced 5 finding(s), 2 RCA candidate(s), and uncertainty 0.16.

## Support

- Supporting observations: obs_75783e870f7d
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.82,
  "consistency_score": 0.75,
  "recency_score": 0.9999999999959888,
  "support_score": 0.3,
  "verification_score": 0.839
}
```
