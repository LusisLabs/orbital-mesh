# Claim claim_dae04f56e82c

- Tier: `semantic`
- State: `active`
- Confidence: `0.613`
- Freshness: `0.9999997590408437`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:13.558270+00:00`

## Statement

Review lane: verify blast radius, rollback semantics, and missing tests before promotion.

## Support

- Supporting observations: obs_96003765fb88, obs_354987e9896b, obs_db4c38a5bcdf
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.6,
  "consistency_score": 0.7,
  "recency_score": 0.9999997590408437,
  "support_score": 0.45,
  "verification_score": 0.35
}
```
