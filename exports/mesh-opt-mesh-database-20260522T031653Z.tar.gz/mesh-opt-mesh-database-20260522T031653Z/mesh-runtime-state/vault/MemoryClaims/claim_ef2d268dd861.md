# Claim claim_ef2d268dd861

- Tier: `semantic`
- State: `active`
- Confidence: `0.613`
- Freshness: `0.9999997561739336`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:13.563270+00:00`

## Statement

Staging operator lane scoped to kind-sregym/google-boutique.

## Support

- Supporting observations: obs_96003765fb88, obs_354987e9896b, obs_db4c38a5bcdf
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.6,
  "consistency_score": 0.7,
  "recency_score": 0.9999997561739336,
  "support_score": 0.45,
  "verification_score": 0.35
}
```
