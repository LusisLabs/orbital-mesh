# Claim claim_1cda2adff823

- Tier: `semantic`
- State: `active`
- Confidence: `0.684`
- Freshness: `0.9999999999925505`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:10.243323+00:00`

## Statement

No fail-closed edge case found.

## Support

- Supporting observations: obs_39a772bb05b3
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.82,
  "consistency_score": 0.75,
  "recency_score": 0.9999999999925505,
  "support_score": 0.3,
  "verification_score": 0.75
}
```
