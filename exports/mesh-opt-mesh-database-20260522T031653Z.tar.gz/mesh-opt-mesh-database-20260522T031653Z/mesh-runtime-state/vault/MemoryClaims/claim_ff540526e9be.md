# Claim claim_ff540526e9be

- Tier: `semantic`
- State: `active`
- Confidence: `0.691`
- Freshness: `0.9999999999908313`
- Superseded By: `none`
- Updated: `2026-05-16T17:01:57.539060+00:00`

## Statement

recent rollback cooldown is active

## Support

- Supporting observations: obs_dbca5a8d84d1
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.82,
  "consistency_score": 0.75,
  "recency_score": 0.9999999999908313,
  "support_score": 0.3,
  "verification_score": 0.8
}
```
