# Claim claim_d4a5080bd7e6

- Tier: `semantic`
- State: `active`
- Confidence: `0.691`
- Freshness: `0.9999999999914044`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:10.233021+00:00`

## Statement

No elevated risk scope detected.

## Support

- Supporting observations: obs_ea9be58a45c1
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.82,
  "consistency_score": 0.75,
  "recency_score": 0.9999999999914044,
  "support_score": 0.3,
  "verification_score": 0.8
}
```
