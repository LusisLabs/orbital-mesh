# Claim claim_b6f41cb6caf2

- Tier: `semantic`
- State: `active`
- Confidence: `0.613`
- Freshness: `0.9999997693268796`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:13.540369+00:00`

## Statement

Operational plan: rollback_deployment for kubernetes_service after evaluation returned execute.

## Support

- Supporting observations: obs_96003765fb88, obs_354987e9896b, obs_db4c38a5bcdf
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.6,
  "consistency_score": 0.7,
  "recency_score": 0.9999997693268796,
  "support_score": 0.45,
  "verification_score": 0.35
}
```
