# Claim claim_32b54b2f9e17

- Tier: `episodic`
- State: `active`
- Confidence: `0.921`
- Freshness: `0.9999998481941317`
- Superseded By: `none`
- Updated: `2026-05-16T16:48:13.535228+00:00`

## Statement

Rollback Kubernetes deployment frontend in google-boutique because the current rollout is unhealthy.

## Support

- Supporting observations: obs_09b689f60b8d, obs_49e1a731ab35, obs_96003765fb88, obs_354987e9896b, obs_db4c38a5bcdf
- Contradicting claims: none

## Confidence Factors

```json
{
  "authority_score": 0.9,
  "consistency_score": 0.8,
  "recency_score": 0.9999998481941317,
  "support_score": 1.0,
  "verification_score": 0.85
}
```
