# Retrieval ret_9c87a8eea750

- Query: `frontend deployment/frontend kubernetes_deployment_unhealthy`
- Channels: lexical, graph, vector
- Created: `2026-05-16T17:01:57.571977+00:00`

## Scope

```json
{
  "run_id": "run_20260516T170154_15cfa48b",
  "service": "frontend"
}
```

## IDs

- Candidate IDs: claim_32b54b2f9e17, frontend, claim_b6f41cb6caf2
- Verified IDs: none
- Discarded IDs: claim_32b54b2f9e17, frontend, claim_b6f41cb6caf2
