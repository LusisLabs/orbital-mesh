# Retrieval ret_15bde3d8e9c3

- Query: `frontend deployment/frontend kubernetes_deployment_unhealthy`
- Channels: lexical, graph, vector
- Created: `2026-05-16T16:48:11.079016+00:00`

## Scope

```json
{
  "endpoint": "deployment/frontend",
  "run_id": "run_20260516T164809_e4a71e58",
  "service": "frontend",
  "shared": true
}
```

## IDs

- Candidate IDs: none
- Verified IDs: none
- Discarded IDs: none
