# Retrieval ret_08c16ab5fa9d

- Query: `frontend deployment/frontend kubernetes_deployment_unhealthy`
- Channels: lexical, graph, vector
- Created: `2026-05-16T16:48:09.815001+00:00`

## Scope

```json
{
  "run_id": "run_20260516T164809_e4a71e58",
  "service": "frontend"
}
```

## IDs

- Candidate IDs: none
- Verified IDs: none
- Discarded IDs: none
